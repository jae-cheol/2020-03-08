package prob3;

public interface Soundable {
	String sound();
}
